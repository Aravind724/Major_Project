from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, confusion_matrix
import joblib
import os
import io

app = Flask(__name__)

# Global variables to store the model and encoders
model = None
le_gender = LabelEncoder()
le_stress = LabelEncoder()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    global model, le_gender, le_stress
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'})
    
    if file:
        # Read the CSV file
        df = pd.read_csv(file)
        
        # Drop unnecessary columns
        df = df.drop(['User_ID', 'Bed_Time', 'Wake_Up_Time'], axis=1)
        
        # Encode categorical variables
        le_gender.fit(df['Gender'])
        df['Gender'] = le_gender.transform(df['Gender'])
        
        le_stress.fit(df['Stress_Level'])
        df['Stress_Level'] = le_stress.transform(df['Stress_Level'])
        
        # Split features and target
        X = df.drop('Stress_Level', axis=1)
        y = df['Stress_Level']
        
        # Split data into train and test sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train the model
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        # Make predictions on test set
        y_pred = model.predict(X_test)
        
        # Calculate accuracy
        accuracy = accuracy_score(y_test, y_pred)
        
        # Calculate confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        
        # Save the model
        joblib.dump(model, 'model.pkl')
        
        # Get feature importances
        feature_importances = model.feature_importances_
        feature_names = X.columns
        importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': feature_importances})
        importance_df = importance_df.sort_values('Importance', ascending=False)
        
        # Convert confusion matrix to list for JSON serialization
        cm_list = cm.tolist()
        
        # Get class names
        class_names = le_stress.classes_.tolist()
        
        return jsonify({
            'success': True,
            'accuracy': float(accuracy),
            'confusion_matrix': cm_list,
            'class_names': class_names,
            'feature_importances': importance_df.to_dict(orient='records')
        })

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        if model is None:
            return jsonify({'error': 'Please upload and train the model first'})
        
        # Get form data
        try:
            age = int(request.form['age'])
            gender = request.form['gender']
            sleep_duration = float(request.form['sleep_duration'])
            sleep_quality = int(request.form['sleep_quality'])
            rem_percentage = float(request.form['rem_percentage'])
            deep_sleep_percentage = float(request.form['deep_sleep_percentage'])
            sleep_interruptions = int(request.form['sleep_interruptions'])
            caffeine_intake = int(request.form['caffeine_intake'])
            exercise_minutes = int(request.form['exercise_minutes'])
            screen_time = int(request.form['screen_time'])
            nap_duration = int(request.form['nap_duration'])
            
            # Encode gender
            gender_encoded = le_gender.transform([gender])[0]
            
            # Create input array for prediction
            input_data = np.array([
                age, gender_encoded, sleep_duration, sleep_quality, 
                rem_percentage, deep_sleep_percentage, sleep_interruptions,
                caffeine_intake, exercise_minutes, screen_time, nap_duration
            ]).reshape(1, -1)
            
            # Make prediction
            prediction = model.predict(input_data)[0]
            
            # Get stress level label
            stress_level = le_stress.inverse_transform([prediction])[0]
            
            # Get prediction probability
            proba = model.predict_proba(input_data)[0]
            max_proba = max(proba) * 100
            
            # Get recommendations based on stress level
            recommendations = get_recommendations(stress_level)
            
            # Get YouTube video ID based on stress level
            video_id = get_youtube_video(stress_level)
            
            return render_template(
                'result.html', 
                stress_level=stress_level,
                confidence=round(max_proba, 2),
                recommendations=recommendations,
                video_id=video_id
            )
            
        except Exception as e:
            return jsonify({'error': str(e)})
    
    return render_template('predict.html')

def get_recommendations(stress_level):
    recommendations = {
        'Low': [
            "Your stress levels are low. Keep up the good work!",
            "Continue with your current sleep routine.",
            "Regular exercise and good sleep hygiene are working well for you."
        ],
        'Moderate': [
            "Your stress levels are moderate. Consider some relaxation techniques.",
            "Try meditation or deep breathing exercises before bed.",
            "Reduce screen time before sleep.",
            "Consider limiting caffeine intake, especially in the afternoon."
        ],
        'High': [
            "Your stress levels are high. Please consider consulting a healthcare professional.",
            "Implement a strict sleep schedule.",
            "Practice relaxation techniques like meditation, yoga, or deep breathing.",
            "Reduce caffeine and increase physical activity.",
            "Consider speaking with a therapist or counselor about stress management strategies."
        ]
    }
    return recommendations.get(stress_level, [])

def get_youtube_video(stress_level):
    videos = {
        'Low': "jfKfPfyJRdk",  # Lofi beats
        'Moderate': "lFcSrYw-ARY",  # Relaxing piano music
        'High': "DWcJFNfaw9c"  # Deep meditation music
    }
    return videos.get(stress_level, "jfKfPfyJRdk")

if __name__ == '__main__':
    app.run(debug=True)
